<?php

defined( 'ABSPATH' ) || exit; 

?>

<header class="header initial">
    <section class="header-colums container">
		
		<section class="header-colum"> 
			<h1 class="logo">
				<a href="#" class="">
					<img class="logo-main-image" alt="logo" src="<?php echo get_option( 'wpc_theme_onepage_checkout_logo', WPC_LOGO_URL ); ?>">
				</a>
			</h1>
		</section>
	
		<section class="header-colum extra"> 
			<section class="header-colum small-title"> 
			</section>
		</section>
    </section>
</header>
<?php defined( 'ABSPATH' ) || exit;

/**
 * Plugin Name: WPC - Onepage Checkout Pro
 * Version: 1.0.0
 * Author: WILLIAN SANTANA
 * Description: A friendly and beautiful 3-column checkout theme to optimize the entire purchase process and significantly increase customer satisfaction.
 * Version: 1.0.0
 */
 
/* Add enqueue CSS e JS */

if ( ! function_exists( 'wpc_onepage_checkout_pro_customize_enqueue' ) ) {

	function  wpc_onepage_checkout_pro_customize_enqueue() {
		
		wp_enqueue_script( 
			'wpc-onepage-checkout-pro-customize',
			plugins_url( 'assets/js/customizer.js', __FILE__ ),
			array( 'jquery' ), 
			'1.0.0',
			true 
		);
		wp_enqueue_style( 
			'wpc-onepage-checkout-pro-customize',
			plugins_url( 'assets/css/customizer.css', __FILE__ ),
			array(), 
			'1.0.0',
			'all' 
		);
	}
	
	add_action( 'customize_controls_enqueue_scripts', 'wpc_onepage_checkout_pro_customize_enqueue', 10 );
}

if ( ! function_exists( 'wpc_onepage_checkout_pro_preview_enqueue' ) ) {

	function  wpc_onepage_checkout_pro_preview_enqueue() {
		
		wp_enqueue_script( 
			'wpc-onepage-checkout-pro-preview',
			plugins_url( 'assets/js/preview.js', __FILE__ ),
			array( 'jquery', 'customize-preview' ),  
			'1.0.0',
			true 
		);
		wp_localize_script(
			'wpc-onepage-checkout-pro-preview',
			'onepagepro',
			array(
				'i18n' => array(
					'label_billing'  => __( 'Billing details', 'woocommerce' ),
					'label_address'  => __( 'Addresses', 'woocommerce' ),
					'label_shipping' => __( 'Shipping options', 'woocommerce'),
					'label_payment'  => __( 'Payment', 'woocommerce' ),
					'label_review'   => __( 'Your order', 'woocommerce' ),

					'description_billing'          => __( 'Enter buyer information', 'WPC' ),
					'description_address_billing'  => __( 'Billing address', 'woocommerce' ),
					'description_address'          => __( 'Shipping address', 'woocommerce' ),
					'description_shipping'         => __( 'Select the desired option below', 'WPC' ),
					'description_payment'          => __( 'Select the desired option below', 'WPC' ),
					'description_review'           => __( 'Order summary', 'woocommerce' ),
					'place_order'                  => __( 'Place order', 'woocommerce' ),
				),
			)
		);
		wp_enqueue_style( 
			'wpc-onepage-checkout-pro-preview',
			plugins_url( 'assets/css/preview.css', __FILE__ ),
			array(), 
			'1.0.0',
			'all' 
		);
	}
	
	add_action( 'customize_register', 'wpc_onepage_checkout_pro_preview_enqueue', 10 );
}

if ( ! function_exists( 'wpc_onepage_checkout_pro_frontend_enqueue' ) ) {

	function  wpc_onepage_checkout_pro_frontend_enqueue() {
		
		wp_enqueue_script( 
			'wpc-onepage-checkout-pro-frontend',
			plugins_url( 'assets/js/frontend.js', __FILE__ ),
			array( 'jquery' ), 
			'1.0.0',
			true 
		);
		wp_enqueue_style( 
			'wpc-onepage-checkout-pro-frontend',
			plugins_url( 'assets/css/frontend.css', __FILE__ ),
			array(), 
			'1.0.0',
			'all' 
		);
		wp_enqueue_style( 
			'wpc-onepage-checkout-pro-flaticon',
			plugins_url( 'assets/css/flaticon.css', __FILE__ ),
			array(), 
			'1.0.0',
			'all' 
		);
		
		wp_localize_script(
			'wpc-onepage-checkout-pro-frontend',
			'onepageprof',
			array(
				'collapsible' => array(
					'mobile'  => get_option( 'wpc_theme_onepage_checkout_mobile_collapsible' ),
					'desktop' => get_option( 'wpc_theme_onepage_checkout_desktop_collapsible' ),
					'text'    => get_option( 'wpc_theme_onepage_checkout_content_forward_button_text', esc_html__( 'Continue', 'WPC' ) ),
				),
			)
		);
		
	}
	
	add_action( 'wp_print_scripts', 'wpc_onepage_checkout_pro_frontend_enqueue', 10 );
}

if ( ! function_exists( 'wpc_onepage_checkout_pro_theme_customizer' ) ) {

	function wpc_onepage_checkout_pro_theme_customizer( $fields, $type, $slug, $version ) {
		
		if ( 'wpc_theme_onepage_checkout' !== $slug ) {
			return $fields;
		}

		$pro_fields = array( 
			'sections' => array( 
				'wpc_onepage_checkout_styles' => array(
				'title' => __( 'Checkout Editor', 'WPC' ),
				'description'  =>  __( '', 'WPC' ),
				'priority' => 10,
				) 
			),
			'settings' => array(
				'wpc_theme_onepage_checkout_font_family' => array( 
					'default'   => 'Arial, Helvetica, sans-serif',
				),
				'wpc_theme_onepage_checkout_font_base' => array(
					'default'   => '12px',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_container_max_width' => array( 
					'default'   => '1024px',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_container_spacing' => array( 
					'default'   => '20px',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_order_button_color' => array( 
					'default'   => '#00899d',
					'transport' => 'postMessage',
				), 
				'wpc_theme_onepage_checkout_content_primary_color' => array( 
					'default'   => '#00646d', 
					'transport' => 'postMessage',
				), 
				'wpc_theme_onepage_checkout_content_primary_text_color' => array( 
					'default'   => '#4a4a4a', 
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-primary-text-color' )
				), 
				'wpc_theme_onepage_checkout_content_decoration_text_color' => array( 
					'default'   => '#ffffff', 
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-primary-text-decoration-color' )
				),
				'wpc_theme_onepage_checkout_form_layout' => array(
				),
				'wpc_theme_onepage_checkout_pro_cart_item_image' => array(
					'default'   => 'yes',
				),
				'wpc_theme_onepage_checkout_heading' => array(
				),
				'wpc_theme_onepage_checkout_content_label_background_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-background-color' )
				),
				'wpc_theme_onepage_checkout_content_label_typography' => array(
					'default'   => '',
					'target'    => array( 'var' => '--wpc-label-font-family' )
				),
				'wpc_theme_onepage_checkout_content_label_typography_weight' => array(
					'default'   => '',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-font-weight' )
				),
				'wpc_theme_onepage_checkout_content_label_typography_size' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_typography_style' => array(
					'default'   => '',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-font-style' )
				),
				'wpc_theme_onepage_checkout_content_label_text_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-text-color' )
				),
				'wpc_theme_onepage_checkout_content_label_height' => array(
					'default'   => '36px',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_radius' => array(
					'default'   => '0px',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-radius' )
				),
				'wpc_theme_onepage_checkout_content_label_text_transform' => array(
					'default'   => 'none',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_border_type' => array(
					'default'   => 'none',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_icon_type' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_icon_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-icon-color' )
				), 
				'wpc_theme_onepage_checkout_content_label_icon_border_style' => array(
					'default'   => '',
					'transport' => 'postMessage',
				), 
				'wpc_theme_onepage_checkout_content_label_icon_border_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-icon-border-color' )
				),  
				'wpc_theme_onepage_checkout_content_label_icon_border_size' => array(
					'default'   => '15px',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-icon-border-size' )
				), 
				'wpc_typography' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_icon_typography' => array(
					'default'   => '',
					'target'    => array( 'var' => '--wpc-label-icon-font-family' )
				),
				'wpc_theme_onepage_checkout_content_label_icon_typography_weight' => array(
					'default'   => '',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-icon-font-weight' )
				),
				'wpc_theme_onepage_checkout_content_label_icon_typography_size' => array(
					'default'   => '',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-icon-font-size' )
				),
				'wpc_theme_onepage_checkout_content_label_icon_typography_style' => array(
					'default'   => '',
					'transport' => 'postMessage',
					'target'    => array( 'var' => '--wpc-label-icon-font-style' )
				),
				'wpc_theme_onepage_checkout_content_label_billing_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_address_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_shipping_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_payment_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_label_review_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_visible' => array(
					'default'   => 'block',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_spacing_top' => array(
					'default'   => '15px',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_spacing_bottom' => array(
					'default'   => '15px',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_background_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_text_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_line_bottom_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_typography' => array(
					'default'   => '',
				),
				'wpc_theme_onepage_checkout_content_description_typography_size' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_typography_weight' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_typography_style' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_billing_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_address_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_address_billing' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_shipping_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_payment_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_description_review_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_box_content_background_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_box_content_border_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_box_content_border_width' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_content_box_content_spacing' => array(
					'default'   => '8px',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_box_content_order_table_background_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_cupom_button_style' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_cupom_button_background_color' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),				
				'wpc_theme_onepage_checkout_mobile_collapsible' => array(
					'default'              => '',
					'sanitize_callback'    => 'wpc_bool_to_string', 
					'sanitize_js_callback' => 'wpc_string_to_bool',
				),				
				'wpc_theme_onepage_checkout_desktop_collapsible' => array(
					'default'              => '',
					'sanitize_callback'    => 'wpc_bool_to_string', 
					'sanitize_js_callback' => 'wpc_string_to_bool',
				),				
				'wpc_theme_onepage_checkout_content_forward_button_text' => array(
					'default' => esc_html__( 'Continue', 'WPC' ),
				),
				'wpc_theme_onepage_checkout_order_button_spacing' => array(
					'default'   => '11px',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_order_button_radius' => array(
					'default'   => '0px',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_order_button_style' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_order_button_typography' => array(
					'default'   => '',
				),
				'wpc_theme_onepage_checkout_order_button_typography_weight' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_order_button_typography_size' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_order_button_text' => array(
					'default'   => '',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_order_button_text_transform' => array(
					'default'   => 'uppercase',
					'transport' => 'postMessage',
				),
				'wpc_theme_onepage_checkout_custom_css' => array(
					'default'   => '',
				),
			),
			'controls' => array(
				'wpc_theme_onepage_checkout_general_heading' => array(
					'class'         =>  'WPC\Control\Heading',
					'label'        =>  __( 'General Settings' , 'WPC' ),
					'description'  =>  __( 'Basic settings for the checkout screen' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_heading'
				),
				'wpc_theme_onepage_checkout_font_family' => array(
					'class'        =>  'WPC\Control\Typography',
					'label'        =>  __( 'Font Family' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_font_family',
					'meta'         =>  array( 'typography' ),
				),
				'wpc_theme_onepage_checkout_font_base' => array(
					'label'        =>  __( 'Base Font Size' , 'WPC' ),
					'class'        =>  'WPC\Control\Range_Value',
					'input_attrs' => array(
						'min'    => 5,
						'max'    => 24,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_font_base'
				),
				'wpc_theme_onepage_checkout_container_max_width' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Container Max Width' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 930,
						'max'    => 1600,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_container_max_width'
				),
				'wpc_theme_onepage_checkout_container_spacing' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Container Spacing' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 0,
						'max'    => 80,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_container_spacing'
				),
				'wpc_theme_onepage_checkout_content_primary_text_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Base Text Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_primary_text_color'
				),
				'wpc_theme_onepage_checkout_content_primary_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Primary Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_primary_color'
				),
				'wpc_theme_onepage_checkout_content_decoration_text_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Decoration Text Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_decoration_text_color'
				),
				'wpc_theme_onepage_checkout_form_layout' => array(
					'type'         =>  'select',
					'choices'      =>  array( 'inline-form' => __( 'Inline', 'WPC' ), '' => __( 'Default', 'WPC' ) ),
					'label'        =>  __( 'Form Layout' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_form_layout'
				),
				'wpc_theme_onepage_checkout_pro_cart_item_image' => array(
					'type'         =>  'select',
					'choices'      =>  array( '' => __( 'No', 'WPC' ), 'yes' => __( 'Yes', 'WPC' ) ),
					'label'        =>  __( 'Enable Product Image' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_pro_cart_item_image'
				),
				//Label background, Label color, Label icon, Label title, Label height, Label subtitle, Label subtitle color
				'wpc_theme_onepage_checkout_label_heading' => array(
					'class'         =>  'WPC\Control\Heading',
					'label'        =>  __( 'Box Label Layout' , 'WPC' ),
					'description'  =>  __( 'Use to change the appearance of the content box label' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_heading'
				),
				'wpc_theme_onepage_checkout_content_label_background_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Label Background Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_background_color'
				),
				'wpc_theme_onepage_checkout_content_label_typography' => array(
					'class'        =>  'WPC\Control\Typography',
					'label'        =>  __( 'Label Font Family' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_typography',
					'meta'         =>  array( 'typography' ),
				),
				'wpc_theme_onepage_checkout_content_label_typography_weight' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Label Font Weight' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 100 => __( 'Thin: 100' ), 200 => __( 'Light: 200' ), 300 => __( 'Book: 300' ), 400 => __( 'Normal: 400' ), 500 => __( 'Medium: 500' ), 600 => __( 'Semibold: 600' ), 700 => __( 'Bold: 700' ), 800 => __( 'Extra Bold: 800' ), 900 => __( 'Black: 900' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_typography_weight',
				),
				'wpc_theme_onepage_checkout_content_label_typography_style' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Label Font Style' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 'normal' => __( 'Normal', 'WPC' ), 'italic' => __( 'Italic', 'WPC' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_typography_style'
				),
				'wpc_theme_onepage_checkout_content_label_typography_size' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Label Font Size' , 'WPC' ),
					'description'  =>  __( 'You can add: px-em-%', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_typography_size'
				),
				'wpc_theme_onepage_checkout_content_label_text_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Label Text Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_text_color'
				),
				'wpc_theme_onepage_checkout_content_label_height' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Label Height' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 36,
						'max'    => 80,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_height'
				),
				'wpc_theme_onepage_checkout_content_label_radius' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Label Radius' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 0,
						'max'    => 10,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_radius'
				),
				'wpc_theme_onepage_checkout_content_label_border_type' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Label Border Type' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 'content' => __( 'Content' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_border_type'
				),
				'wpc_theme_onepage_checkout_content_label_text_transform' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Label Text Transform' , 'WPC' ),
					'choices'      =>  array( 'none' => __( 'Default', 'WPC' ), 'uppercase' => __( 'Uppercase' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_text_transform'
				),
				'wpc_theme_onepage_checkout_content_label_icon_type' => array(
					'type'         =>  'select',
					'choices'      =>  array( '' => __( 'Numeric', 'WPC' ), 'image' => __( 'Image', 'WPC' ) ),
					'label'        =>  __( 'Label Icon Type' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_type'
				),
				'wpc_theme_onepage_checkout_content_label_icon_typography' => array(
					'class'        =>  'WPC\Control\Typography',
					'label'        =>  __( 'Label Icon Font Family' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_typography',
					'meta'         =>  array( 'typography' ),
				),
				'wpc_theme_onepage_checkout_content_label_icon_typography_weight' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Label Icon Font Weight' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 100 => __( 'Thin: 100' ), 200 => __( 'Light: 200' ), 300 => __( 'Book: 300' ), 400 => __( 'Normal: 400' ), 500 => __( 'Medium: 500' ), 600 => __( 'Semibold: 600' ), 700 => __( 'Bold: 700' ), 800 => __( 'Extra Bold: 800' ), 900 => __( 'Black: 900' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_typography_weight'
				),
				'wpc_theme_onepage_checkout_content_label_icon_typography_style' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Label Icon Font Style' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 'normal' => __( 'Normal', 'WPC' ), 'italic' => __( 'Italic', 'WPC' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_typography_style'
				),
				'wpc_theme_onepage_checkout_content_label_icon_typography_size' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Label Icon Font Size' , 'WPC' ),
					'description'  =>  __( 'You can add: px-em-%', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_typography_size'
				),
				'wpc_theme_onepage_checkout_content_label_icon_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Label Icon Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_color'
				),
				'wpc_theme_onepage_checkout_content_label_icon_border_style' => array(
					'type'         =>  'select',
					'choices'      =>  array( '' => __( 'None', 'WPC' ), 'round' => __( 'Round', 'WPC' ), 'square' => __( 'Square', 'WPC' ) ),
					'label'        =>  __( 'Label Icon Border' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_border_style'
				),
				'wpc_theme_onepage_checkout_content_label_icon_border_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Label Icon Border Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_border_color'
				),
				'wpc_theme_onepage_checkout_content_label_icon_border_size' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Label Icon Border Size' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 15,
						'max'    => 45,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_border_size'
				),
				'wpc_theme_onepage_checkout_content_label_icon_size' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Label Icon Size' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 5,
						'max'    => 50,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_icon_size'
				),
				'wpc_theme_onepage_checkout_label_text_heading' => array(
					'class'         =>  'WPC\Control\Heading',
					'label'        =>  __( 'Label Content Text' , 'WPC' ),
					'description'  =>  __( 'Use to edit the content label text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_heading'
				),
				'wpc_theme_onepage_checkout_content_label_billing_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Label Billing Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_billing_text'
				),
				'wpc_theme_onepage_checkout_content_label_address_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Label Address Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_address_text'
				),
				'wpc_theme_onepage_checkout_content_label_shipping_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Label Shipping Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_shipping_text'
				),
				'wpc_theme_onepage_checkout_content_label_payment_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Label Payment Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_payment_text'
				),
				'wpc_theme_onepage_checkout_content_label_review_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Label Review Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_label_review_text'
				),
				'wpc_theme_onepage_checkout_description_heading' => array(
					'class'         =>  'WPC\Control\Heading',
					'label'        =>  __( 'Box Description Layout' , 'WPC' ),
					'description'  =>  __( 'Use to change the appearance of the content box description' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_heading'
				),
				'wpc_theme_onepage_checkout_content_description_visible' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Description Visible' , 'WPC' ),
					'choices'      =>  array( 'block' => __( 'Yes', 'WPC' ), 'none' => __( 'No', 'WPC' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_visible'
				),
				'wpc_theme_onepage_checkout_content_description_spacing_top' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Description Spacing Top' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 0,
						'max'    => 30,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_spacing_top'
				),
				'wpc_theme_onepage_checkout_content_description_spacing_bottom' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Description Spacing Bottom' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 0,
						'max'    => 30,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_spacing_bottom'
				),
				'wpc_theme_onepage_checkout_content_description_background_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Description Background Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_background_color'
				),
				'wpc_theme_onepage_checkout_content_description_text_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Description Text Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_text_color'
				),
				'wpc_theme_onepage_checkout_content_description_line_bottom_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Description Line Bottom Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_line_bottom_color'
				),
				'wpc_theme_onepage_checkout_content_description_typography' => array(
					'class'        =>  'WPC\Control\Typography',
					'label'        =>  __( 'Description Font Family' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_typography',
					'meta'         =>  array( 'typography' ),
				),
				'wpc_theme_onepage_checkout_content_description_typography_weight' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Description Font Weight' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 100 => __( 'Thin: 100' ), 200 => __( 'Light: 200' ), 300 => __( 'Book: 300' ), 400 => __( 'Normal: 400' ), 500 => __( 'Medium: 500' ), 600 => __( 'Semibold: 600' ), 700 => __( 'Bold: 700' ), 800 => __( 'Extra Bold: 800' ), 900 => __( 'Black: 900' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_typography_weight'
				),
				'wpc_theme_onepage_checkout_content_description_typography_style' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Description Font Style' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 'normal' => __( 'Normal', 'WPC' ), 'italic' => __( 'Italic', 'WPC' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_typography_style'
				),
				'wpc_theme_onepage_checkout_content_description_typography_size' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Description Font Size' , 'WPC' ),
					'description'  =>  __( 'You can add: px-em-%', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_typography_size'
				),
				'wpc_theme_onepage_checkout_description_text_heading' => array(
					'class'         =>  'WPC\Control\Heading',
					'label'        =>  __( 'Description Content Text' , 'WPC' ),
					'description'  =>  __( 'Use to edit the content description text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_heading'
				),
				'wpc_theme_onepage_checkout_content_description_billing_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Description Billing Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_billing_text'
				),
				'wpc_theme_onepage_checkout_content_description_address_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Description Address Shipping Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_address_text'
				),
				'wpc_theme_onepage_checkout_content_description_address_billing' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Description Address Billing Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_address_billing'
				), 
				'wpc_theme_onepage_checkout_content_description_shipping_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Description Shipping Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_shipping_text'
				),
				'wpc_theme_onepage_checkout_content_description_payment_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Description Payment Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_payment_text'
				),
				'wpc_theme_onepage_checkout_content_description_review_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Description Review Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_description_review_text'
				),
				'wpc_theme_onepage_checkout_box_content_heading' => array(
					'class'         =>  'WPC\Control\Heading',
					'label'        =>  __( 'Box Content Layout' , 'WPC' ),
					'description'  =>  __( 'Use to edit the box content' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_heading'
				),
				'wpc_theme_onepage_checkout_content_box_content_background_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Box Content Background Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_box_content_background_color'
				),
				'wpc_theme_onepage_checkout_content_box_content_border_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Box Content Border Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_box_content_border_color'
				),
				'wpc_theme_onepage_checkout_content_box_content_border_width' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Box Content Border Width' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 0,
						'max'    => 10,
						'suffix' => 'px',
					),
					'description'  =>  __( 'You can add: px-em-%', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_box_content_border_width'
				),
				'wpc_theme_onepage_checkout_content_box_content_spacing' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Box Content Spacing' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 0,
						'max'    => 25,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_box_content_spacing'
				),
				'wpc_theme_onepage_checkout_box_content_order_table_background_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Order Table Background Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_box_content_order_table_background_color'
				),
				'wpc_theme_onepage_checkout_cupom_button_style' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Cupom Button Style' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 'cupom_button_outline' => __( 'Outline', 'WPC' ), 'cupom_button_3d' => __( '3D', 'WPC' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_cupom_button_style'
				),
				'wpc_theme_onepage_checkout_cupom_button_background_color' => array(
					'class'        =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Cupom Button Background Color', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_cupom_button_background_color'
				),
				'wpc_theme_onepage_checkout_mobile_collapsible' => array(
					'type'         =>  'checkbox',
					'label'        =>  __( 'Mobile Collapsible Content ', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_mobile_collapsible'
				),
				'wpc_theme_onepage_checkout_desktop_collapsible' => array(
					'type'         =>  'checkbox',
					'label'        =>  __( 'Desktop Collapsible Content ', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_desktop_collapsible'
				),
				'wpc_theme_onepage_checkout_content_forward_button_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Forward button text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_content_forward_button_text'
				),
				'wpc_theme_onepage_checkout_order_button_heading' => array(
					'class'         =>  'WPC\Control\Heading',
					'label'        =>  __( 'Button Place Order Layout' , 'WPC' ),
					'description'  =>  __( 'Use to edit the button place order' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_heading'
				),
				'wpc_theme_onepage_checkout_order_button_color' => array(
					'class'         =>  'WP_Customize_Color_Control',
					'label'        =>  __( 'Button Place Order Color' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_order_button_color'
				),
				'wpc_theme_onepage_checkout_order_button_spacing' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Place Order Button Spacing' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 5,
						'max'    => 15,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_order_button_spacing'
				),
				'wpc_theme_onepage_checkout_order_button_radius' => array(
					'class'        =>  'WPC\Control\Range_Value',
					'label'        =>  __( 'Place Order Button Radius' , 'WPC' ),
					'input_attrs' => array(
						'min'    => 0,
						'max'    => 10,
						'suffix' => 'px',
					),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_order_button_radius'
				),
				'wpc_theme_onepage_checkout_order_button_style' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Place Order Button Style' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 'order_button_outline' => __( 'Outline', 'WPC' ), 'order_button_shadow' => __( 'Shadow', 'WPC' ), 'order_button_3d' => __( '3D', 'WPC' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_order_button_style'
				),
				'wpc_theme_onepage_checkout_order_button_typography' => array(
					'class'        =>  'WPC\Control\Typography',
					'label'        =>  __( 'Place Order Button Font Family', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_order_button_typography',
					'meta'         =>  array( 'typography' ),
				),
				'wpc_theme_onepage_checkout_order_button_typography_weight' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Place Order Button Font Weight' , 'WPC' ),
					'choices'      =>  array( '' => __( 'Default', 'WPC' ), 100 => __( 'Thin: 100' ), 200 => __( 'Light: 200' ), 300 => __( 'Book: 300' ), 400 => __( 'Normal: 400' ), 500 => __( 'Medium: 500' ), 600 => __( 'Semibold: 600' ), 700 => __( 'Bold: 700' ), 800 => __( 'Extra Bold: 800' ), 900 => __( 'Black: 900' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_order_button_typography_weight'
				),
				'wpc_theme_onepage_checkout_order_button_typography_size' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Place Order Button Font Size' , 'WPC' ),
					'description'  =>  __( 'You can add: px-em-%', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_order_button_typography_size'
				),
				'wpc_theme_onepage_checkout_order_button_text' => array(
					'type'         =>  'text',
					'label'        =>  __( 'Place Order Button Text' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_order_button_text'
				),
				'wpc_theme_onepage_checkout_order_button_text_transform' => array(
					'type'         =>  'select',
					'label'        =>  __( 'Place Order Text Transform' , 'WPC' ),
					'choices'      =>  array( 'none' => __( 'Default', 'WPC' ), 'uppercase' => __( 'Uppercase' ) ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_order_button_text_transform'
				),
				'wpc_theme_onepage_checkout_custom_style_heading' => array(
					'class'         =>  'WPC\Control\Heading',
					'label'        =>  __( 'Custom Style' , 'WPC' ),
					'description'  =>  __( 'Use to add custom styles rules' , 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_heading'
				),
				'wpc_theme_onepage_checkout_custom_css' => array(
					'type'         =>  'textarea',
					'label'        =>  __( 'Custom CSS', 'WPC' ),
					'section'      =>  'wpc_onepage_checkout_styles',
					'settings'     =>  'wpc_theme_onepage_checkout_custom_css',
				),
			),
		);
		
		return $pro_fields;
	}
	
	add_action( 'wpc_addon_customizer', 'wpc_onepage_checkout_pro_theme_customizer', 10, 4 );
}

/* Add group box shipping */

if ( ! function_exists( 'wpc_onepage_checkout_pro_groups_and_fields' ) ) {

	function wpc_onepage_checkout_pro_groups_and_fields( $control ) {
		
		if ( !isset( $control['billing_address'] ) ) {
			$control['billing_address']['id'] = 'billing_address';
			$control['billing_address']['title'] = __( 'Billing Address', 'wpc-onepage-checkout-pro' );
			$control['billing_address']['enableDelete'] = false;
			$control['billing_address']['addFields'] = true;
			$control['billing_address']['removeFields'] = true;
			$control['billing_address']['moveFields'] = true;
			$control['billing_address']['limitIncontext'] = false;
			$control['billing_address']['customGroup'] = true;
			$control['billing_address']['children'] = array();	
		}
		
		return $control;
	}
	
	add_filter( 'wpc_field_manager_saved_groups_and_fields', 'wpc_onepage_checkout_pro_groups_and_fields', 10 );
}

if ( ! function_exists( 'wpc_onepage_checkout_pro_groups_and_fields_html_content' ) ) {

	function wpc_onepage_checkout_pro_groups_and_fields_html_content( $checkout ) {
		
		$fields = $checkout->get_checkout_fields();
		
		if( isset( $fields['billing_address'] ) && !empty( $fields['billing_address'] ) ) {
			
			$html = '<section class="content-box-frame"> ';
			$html .= '<div class="woocommerce-billing-address-fields">';
			$html .= '<h3 class="content-box-subtitle billing-address"><span>' . apply_filters( 'wpc_onepage_checkout_print_content_box_description', __( 'Billing address', 'woocommerce' ), 'addresses-billing' ) . '</span></h3>';
			$html .= '<div class="billing_address">';
			$html .= '<div class="woocommerce-shipping-fields__field-wrapper">';
			
			foreach ( $fields['billing_address'] as $key => $field ) {
				$html .= woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
			}
			
			$html .= '</div>';
			$html .= '</div>';
			$html .= '</div>';
			$html .= '</section>';
			
			print( $html );
		}
		
	}
	
	add_action( 'wpc_onepage_checkout_before_content_box_shipping_fields', 'wpc_onepage_checkout_pro_groups_and_fields_html_content', 10 );
}

if ( ! function_exists( 'wpc_onepage_checkout_pro_before_checkout_print_field' ) ) {

	function wpc_onepage_checkout_pro_before_checkout_print_field( $field, $fid, $gid ) {
		
		if ( 'billing_address' === $gid ) {
			$field['return'] = true;
		}
		
		return $field;
	}
	
	add_filter( 'wpc_field_manager_incheckout_group_field', 'wpc_onepage_checkout_pro_before_checkout_print_field', 10, 3 );
}


/* Add cart item image */

if ( ! function_exists( 'wpc_onepage_checkout_pro_add_cart_item_image' ) ) {

	function wpc_onepage_checkout_pro_add_cart_item_image( $product_get_image, $cart_item, $cart_item_key ) {
		
		if ( is_null( $product_get_image ) 
			|| empty( $product_get_image ) 
			|| !isset( $product_get_image )
			|| 'yes' !== get_option( 'wpc_theme_onepage_checkout_pro_cart_item_image', 'yes' ) ) {
				return;
		}
		
		$html = '<td class="product-image" style="">';
		$html .= apply_filters( 'woocommerce_cart_item_thumbnail', $product_get_image, $cart_item, $cart_item_key );
		$html .= '</td>';

		print( $html );
	}
	
	add_action( 'wpc_onepage_checkout_cart_item_image', 'wpc_onepage_checkout_pro_add_cart_item_image', 10, 3 );
}

/* Add body class */

if ( ! function_exists( 'wpc_onepage_checkout_pro_body_classes' ) ) {

	function wpc_onepage_checkout_pro_body_classes( $classes ) {
		
		$label_icon_type    = get_option( 'wpc_theme_onepage_checkout_content_label_icon_type', '' );
		$label_icon_style   = get_option( 'wpc_theme_onepage_checkout_content_label_icon_border_style', '' );
		$label_border_type  = get_option( 'wpc_theme_onepage_checkout_content_label_border_type', '' );
		$order_button_style = get_option( 'wpc_theme_onepage_checkout_order_button_style', '' );
		$cupom_button_style = get_option( 'wpc_theme_onepage_checkout_cupom_button_style', '' );
		
		if ( 'image' === $label_icon_type ) {
			$classes[] = 'content-box-icon';
		}
		if ( 'square' === $label_icon_style ) {
			$classes[] = 'icon-style-square';
		}
		if ( 'round' === $label_icon_style ) {
			$classes[] = 'icon-style-square';
			$classes[] = 'icon-style-round';
		}
		if ( 'content' === $label_border_type ) {
			$classes[] = 'label-content-border';
		}
		if ( '' !== $order_button_style ) {
			$classes[] = $order_button_style;
		}
		if ( '' !== $cupom_button_style ) {
			$classes[] = $cupom_button_style;
		}
	  
		return $classes;
	}
	
	add_filter( 'wpc_content_class', 'wpc_onepage_checkout_pro_body_classes' );
}

/* Change label text */

if ( ! function_exists( 'wpc_onepage_checkout_pro_edit_content_box_title' ) ) {

	function wpc_onepage_checkout_pro_edit_content_box_title( $_text, $type ) {
		switch ( $type ) {
			case 'billing':
				$text = get_option( 'wpc_theme_onepage_checkout_content_label_billing_text' );
				break;
			case 'address':
				$text = get_option( 'wpc_theme_onepage_checkout_content_label_address_text' );
				break;
			case 'shipping':
				$text = get_option( 'wpc_theme_onepage_checkout_content_label_shipping_text' );
				break;
			case 'payment':
				$text = get_option( 'wpc_theme_onepage_checkout_content_label_payment_text' );
				break;
			case 'review':
				$text = get_option( 'wpc_theme_onepage_checkout_content_label_review_text' );
				break;
		}
		
		if ( isset( $text ) && !empty( $text ) ) {
			return $text;
		} else {
			return $_text;
		}

	}
	
	add_filter( 'wpc_onepage_checkout_print_content_box_title', 'wpc_onepage_checkout_pro_edit_content_box_title', 10, 2 );
}

/* Change place order text */

if ( ! function_exists( 'wpc_onepage_checkout_pro_edit_order_button_text' ) ) {

	function wpc_onepage_checkout_pro_edit_order_button_text( $_text ) {
		$text = get_option( 'wpc_theme_onepage_checkout_order_button_text' );
		
		if ( !empty( $text ) ) {
			return $text;
		} else {
			return $_text;
		}

	}
	
	add_filter( 'wpc_onepage_checkout_order_button_text', 'wpc_onepage_checkout_pro_edit_order_button_text', 10 );
}

/* Add custom CSS */

if ( ! function_exists( 'wpc_onepage_checkout_pro_add_custom_css' ) ) {

	function wpc_onepage_checkout_pro_add_custom_css() {
		$css = get_option( 'wpc_theme_onepage_checkout_custom_css' );
		
		if ( !empty( $css ) ) {
			print( $css );
		}
	}
	
	add_action( 'wpc_theme_compatibility_print_css', 'wpc_onepage_checkout_pro_add_custom_css', 10 );
}

/* Change description text */

if ( ! function_exists( 'wpc_onepage_checkout_pro_edit_content_box_description' ) ) {

	function wpc_onepage_checkout_pro_edit_content_box_description( $_text, $type ) {
		switch ( $type ) {
			case 'billing':
				$text = get_option( 'wpc_theme_onepage_checkout_content_description_billing_text' );
				break;
			case 'address-billing':
				$text = get_option( 'wpc_theme_onepage_checkout_content_description_address_billing' );
				break;
			case 'address':
				$text = get_option( 'wpc_theme_onepage_checkout_content_description_address_text' );
				break;
			case 'shipping':
				$text = get_option( 'wpc_theme_onepage_checkout_content_description_shipping_text' );
				break;
			case 'payment':
				$text = get_option( 'wpc_theme_onepage_checkout_content_description_payment_text' );
				break;
			case 'review':
				$text = get_option( 'wpc_theme_onepage_checkout_content_description_review_text' );
				break;
		}
		
		if ( isset( $text ) && !empty( $text ) ) {
			return $text;
		} else {
			return $_text;
		}

	}
	
	add_filter( 'wpc_onepage_checkout_print_content_box_description', 'wpc_onepage_checkout_pro_edit_content_box_description', 10, 2 );
}

/* Change CSS vars */

if ( ! function_exists( 'wpc_onepage_checkout_pro_css_vars' ) ) {

	function wpc_onepage_checkout_pro_css_vars( $_css_vars ) {
		
		$css_vars['--wpc-label-icon-border-size'] = get_option( 'wpc_theme_onepage_checkout_content_label_icon_border_size' ) ?: '15px';		
		$css_vars['--wpc-primary-text-color'] = get_option( 'wpc_theme_onepage_checkout_content_primary_text_color' ) ?: $_css_vars['--wpc-primary-text-color'];
		$css_vars['--wpc-primary-text-decoration-color'] = get_option( 'wpc_theme_onepage_checkout_content_decoration_text_color' ) ?: $_css_vars['--wpc-primary-text-decoration-color'];
		$css_vars['--wpc-base-font-family'] = get_option( 'wpc_theme_onepage_checkout_font_family' ) ?: $_css_vars['--wpc-base-font-family'];
		$css_vars['--wpc-base-font-size'] = get_option( 'wpc_theme_onepage_checkout_font_base' ) ?: $_css_vars['--wpc-base-font-size'];
		$css_vars['--wpc-label-background-color'] = get_option( 'wpc_theme_onepage_checkout_content_label_background_color' ) ?: $_css_vars['--wpc-label-background-color'];
		$css_vars['--wpc-label-text-color'] = get_option( 'wpc_theme_onepage_checkout_content_label_text_color' ) ?: $_css_vars['--wpc-label-text-color'];
		$css_vars['--wpc-label-font-family'] = get_option( 'wpc_theme_onepage_checkout_content_label_typography' ) ?: $_css_vars['--wpc-label-font-family'];
		$css_vars['--wpc-label-font-weight'] = get_option( 'wpc_theme_onepage_checkout_content_label_typography_weight' ) ?: $_css_vars['--wpc-label-font-weight'];
		$css_vars['--wpc-label-font-size'] = get_option( 'wpc_theme_onepage_checkout_content_label_typography_size' ) ?: $_css_vars['--wpc-label-font-size'];
		$css_vars['--wpc-label-font-style'] = get_option( 'wpc_theme_onepage_checkout_content_label_typography_style' ) ?: $_css_vars['--wpc-label-font-style'];
		$css_vars['--wpc-label-height'] = get_option( 'wpc_theme_onepage_checkout_content_label_height' ) ?: $_css_vars['--wpc-label-height'];
		$css_vars['--wpc-label-radius'] = get_option( 'wpc_theme_onepage_checkout_content_label_radius' ) ?: $_css_vars['--wpc-label-radius'];
		$css_vars['--wpc-label-text-transform'] = get_option( 'wpc_theme_onepage_checkout_content_label_text_transform' ) ?: $_css_vars['--wpc-label-text-transform'];
		$css_vars['--wpc-label-icon-color'] = get_option( 'wpc_theme_onepage_checkout_content_label_icon_color' ) ?: $_css_vars['--wpc-label-icon-color'];
		$css_vars['--wpc-label-icon-border-color'] = get_option( 'wpc_theme_onepage_checkout_content_label_icon_border_color' ) ?: $_css_vars['--wpc-label-icon-border-color'];
		$css_vars['--wpc-label-icon-font-family'] = get_option( 'wpc_theme_onepage_checkout_content_label_icon_typography' ) ?: $_css_vars['--wpc-label-icon-font-family'];
		$css_vars['--wpc-label-icon-font-weight'] = get_option( 'wpc_theme_onepage_checkout_content_label_icon_typography_weight' ) ?: $_css_vars['--wpc-label-icon-font-weight'];
		$css_vars['--wpc-label-icon-font-size'] = get_option( 'wpc_theme_onepage_checkout_content_label_icon_typography_size' ) ?: $_css_vars['--wpc-label-icon-font-size'];
		$css_vars['--wpc-label-icon-font-style'] = get_option( 'wpc_theme_onepage_checkout_content_label_icon_typography_style' ) ?: $_css_vars['--wpc-label-icon-font-style'];
		
		$css_vars['--wpc-description-visible'] = get_option( 'wpc_theme_onepage_checkout_content_description_visible' ) ?: $_css_vars['--wpc-description-visible'];
		$css_vars['--wpc-description-spacing-top'] = get_option( 'wpc_theme_onepage_checkout_content_description_spacing_top' ) ?: $_css_vars['--wpc-description-spacing-top'];
		$css_vars['--wpc-description-spacing-bottom'] = get_option( 'wpc_theme_onepage_checkout_content_description_spacing_bottom' ) ?: $_css_vars['--wpc-description-spacing-bottom'];
		$css_vars['--wpc-description-background-color'] = get_option( 'wpc_theme_onepage_checkout_content_description_background_color' ) ?: $_css_vars['--wpc-description-background-color'];
		$css_vars['--wpc-description-text-color'] = get_option( 'wpc_theme_onepage_checkout_content_description_text_color' ) ?: $_css_vars['--wpc-description-text-color'];
		$css_vars['--wpc-description-line-bottom-color'] = get_option( 'wpc_theme_onepage_checkout_content_description_line_bottom_color' ) ?: $_css_vars['--wpc-description-line-bottom-color'];
		$css_vars['--wpc-description-font-family'] = get_option( 'wpc_theme_onepage_checkout_content_description_typography' ) ?: $_css_vars['--wpc-description-font-family'];
		$css_vars['--wpc-description-font-weight'] = get_option( 'wpc_theme_onepage_checkout_content_description_typography_weight' ) ?: $_css_vars['--wpc-description-font-weight'];
		$css_vars['--wpc-description-font-size'] = get_option( 'wpc_theme_onepage_checkout_content_description_typography_size' ) ?: $_css_vars['--wpc-description-font-size'];
		$css_vars['--wpc-description-font-style'] = get_option( 'wpc_theme_onepage_checkout_content_description_typography_style' ) ?: $_css_vars['--wpc-description-font-style'];
		
		$css_vars['--wpc-content-box-background-color'] = get_option( 'wpc_theme_onepage_checkout_content_box_content_background_color' ) ?: $_css_vars['--wpc-content-box-background-color'];
		$css_vars['--wpc-content-box-border-color'] = get_option( 'wpc_theme_onepage_checkout_content_box_content_border_color' ) ?: $_css_vars['--wpc-content-box-border-color'];
		$css_vars['--wpc-content-box-border-width'] = get_option( 'wpc_theme_onepage_checkout_content_box_content_border_width' ) ?: $_css_vars['--wpc-content-box-border-width'];
		$css_vars['--wpc-content-box-spacing'] = get_option( 'wpc_theme_onepage_checkout_content_box_content_spacing' ) ?: $_css_vars['--wpc-content-box-spacing'];
		$css_vars['--wpc-content-box-order-button-spacing'] = get_option( 'wpc_theme_onepage_checkout_order_button_spacing' ) ?: $_css_vars['--wpc-content-box-order-button-spacing'];
		$css_vars['--wpc-content-box-order-button-radius'] = get_option( 'wpc_theme_onepage_checkout_order_button_radius' ) ?: $_css_vars['--wpc-content-box-order-button-radius'];
		$css_vars['--wpc-content-box-order-button-font-family'] = get_option( 'wpc_theme_onepage_checkout_order_button_typography' ) ?: $_css_vars['--wpc-content-box-order-button-font-family'];
		$css_vars['--wpc-content-box-order-button-font-family-weight'] = get_option( 'wpc_theme_onepage_checkout_order_button_typography_weight' ) ?: $_css_vars['--wpc-content-box-order-button-font-weight'];
		$css_vars['--wpc-content-box-order-button-font-family-size'] = get_option( 'wpc_theme_onepage_checkout_order_button_typography_size' ) ?: $_css_vars['--wpc-content-box-order-button-font-size'];
		$css_vars['--wpc-content-box-order-table-background-color'] = get_option( 'wpc_theme_onepage_checkout_box_content_order_table_background_color' ) ?: $_css_vars['--wpc-content-box-order-table-background-color'];
		$css_vars['--wpc-content-box-cupom_button-background-color'] = get_option( 'wpc_theme_onepage_checkout_cupom_button_background_color' ) ?: $_css_vars['--wpc-content-box-cupom_button-background-color'];
		$css_vars['--wpc-content-box-order-button-text-transform'] = get_option( 'wpc_theme_onepage_checkout_order_button_text_transform' ) ?: $_css_vars['--wpc-content-box-order-button-text-transform'];

		return(
			array_replace(
				$_css_vars,
				$css_vars
			)
		);
	}
	
	add_action( 'wpc_onepage_checkout_css_vars', 'wpc_onepage_checkout_pro_css_vars', 10 );
}

if ( ! function_exists( 'wpc_onepage_checkout_pro_controls_active_callback' ) ) {

	function  wpc_onepage_checkout_pro_controls_active_callback( $status, $type, $slug, $id ) {

		$label_icon_type = get_option( 'wpc_theme_onepage_checkout_content_label_icon_type' );

		$to_image_label_icon_type = array(
			'wpc_theme_onepage_checkout_content_label_icon_typography',
			'wpc_theme_onepage_checkout_content_label_icon_typography_weight',
			'wpc_theme_onepage_checkout_content_label_icon_typography_style',
		);

		if ( 'image' === $label_icon_type && in_array( $id, $to_image_label_icon_type ) ) {
			return false;
		}
		
		$label_icon_border_style = get_option( 'wpc_theme_onepage_checkout_content_label_icon_border_style' );
		
		$to_empty_label_icon_border_style = array(
			'wpc_theme_onepage_checkout_content_label_icon_border_color',
			'wpc_theme_onepage_checkout_content_label_icon_border_size'
		);
		
		if ( '' === $label_icon_border_style && in_array( $id, $to_empty_label_icon_border_style ) ) {
			return false;
		}
		
		return $status;
	}
	
	add_action( 'wpc_addon_control_active_callback', 'wpc_onepage_checkout_pro_controls_active_callback', 10, 4 );
}

/* Load Framework addons*/
if ( ! function_exists( 'wpc_onepage_checkout_pro_load_addons' ) ) {

	function wpc_onepage_checkout_pro_load_addons( $addons ) {
		require_once dirname( __FILE__ ) . '/addons/wpc-onepage-checkout/class-wpc-theme-onepage-checkout.php';
		
		$addons[] = 'WPC\Theme\Onepage_Checkout';
		$addons[] = 'WPC\Extension\Theme_Compatibility';
		$addons[] = 'WPC\Extension\Theme_Selector';
		$addons[] = 'WPC\Extension\Typography_Settings';
		$addons[] = 'WPC\Extension\Template_Selector';
		
		return $addons;
	}
	
	add_filter( 'wpc_addons', 'wpc_onepage_checkout_pro_load_addons', 10 );
}

if ( ! function_exists( 'wpc_onepage_checkout_pro_template_customizer' ) ) {

	function wpc_onepage_checkout_pro_template_customizer( $fields, $type, $slug, $version ) {		
		
		if ( 'wpc_template_selector' !== $slug ) {
			return $fields;
		}

		$fields['controls']['wpc_onepage_checkout_template_clean_text_heading'] = array(
			'class'           => 'WPC\Control\Heading',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'label'           => 'Clean'
		);

		$fields['controls']['wpc_onepage_checkout_template_clean'] = array(
			'class'           => 'WPC\Control\Card_Selector',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'cards'           => array(
				array(
					'screenshot' => plugins_url( 'assets/img/templates/clean-00bfb3.png', __FILE__ ),
					'action' => array( 
						'id' => 'clean#00bfb3', 
						'value' => '{"wpc_theme_onepage_checkout_mobile_collapsible":"yes","wpc_theme_onepage_checkout_desktop_collapsible":"yes","wpc_theme_onepage_checkout_content_label_icon_border_style":"","wpc_theme_onepage_checkout_font_family":"Nunito","wpc_theme_onepage_checkout_font_base":"14px","wpc_theme_onepage_checkout_container_max_width":"1200px","wpc_theme_onepage_checkout_container_spacing":"50px","wpc_theme_onepage_checkout_content_primary_text_color":"#333333","wpc_theme_onepage_checkout_content_primary_color":"#ffffff","wpc_theme_onepage_checkout_content_decoration_text_color":"#ffffff","wpc_theme_onepage_checkout_form_layout":"inline-form","wpc_theme_onepage_checkout_pro_cart_item_image":"yes","wpc_theme_onepage_checkout_content_label_background_color":"#ffffff","wpc_theme_onepage_checkout_content_label_typography":"Poppins","wpc_theme_onepage_checkout_content_label_typography_weight":"700","wpc_theme_onepage_checkout_content_label_typography_style":"","wpc_theme_onepage_checkout_content_label_typography_size":"","wpc_theme_onepage_checkout_content_label_text_color":"#000000","wpc_theme_onepage_checkout_content_label_height":"70px","wpc_theme_onepage_checkout_content_label_radius":"3px","wpc_theme_onepage_checkout_content_label_text_transform":"uppercase","wpc_theme_onepage_checkout_content_label_icon_type":"","wpc_theme_onepage_checkout_content_label_icon_typography":"Poppins","wpc_theme_onepage_checkout_content_label_icon_typography_weight":"700","wpc_theme_onepage_checkout_content_label_icon_typography_style":"normal","wpc_theme_onepage_checkout_content_label_icon_typography_size":"1.2em","wpc_theme_onepage_checkout_content_label_icon_color":"#000000","wpc_theme_onepage_checkout_content_label_icon_border_color":"#1a5d84","wpc_theme_onepage_checkout_content_description_visible":"block","wpc_theme_onepage_checkout_content_description_spacing_top":"0px","wpc_theme_onepage_checkout_content_description_spacing_bottom":"20px","wpc_theme_onepage_checkout_content_description_background_color":"#ffffff","wpc_theme_onepage_checkout_content_description_text_color":"#000000","wpc_theme_onepage_checkout_content_description_line_bottom_color":"#f1f1f1","wpc_theme_onepage_checkout_content_description_typography":"Poppins","wpc_theme_onepage_checkout_content_description_typography_weight":"700","wpc_theme_onepage_checkout_content_description_typography_style":"","wpc_theme_onepage_checkout_content_description_typography_size":"","wpc_theme_onepage_checkout_content_box_content_background_color":"#ffffff","wpc_theme_onepage_checkout_content_box_content_border_color":"#bbbbbb","wpc_theme_onepage_checkout_content_box_content_border_width":"1px","wpc_theme_onepage_checkout_content_box_content_spacing":"16px","wpc_theme_onepage_checkout_box_content_order_table_background_color":"","wpc_theme_onepage_checkout_cupom_button_style":"cupom_button_outline","wpc_theme_onepage_checkout_cupom_button_background_color":"#00bfb3","wpc_theme_onepage_checkout_order_button_color":"#00bfb3","wpc_theme_onepage_checkout_order_button_spacing":"10px","wpc_theme_onepage_checkout_order_button_radius":"3px","wpc_theme_onepage_checkout_order_button_style":"order_button_shadow","wpc_theme_onepage_checkout_order_button_typography":"Poppins","wpc_theme_onepage_checkout_order_button_typography_weight":"700","wpc_theme_onepage_checkout_order_button_typography_size":"","wpc_theme_onepage_checkout_order_button_text":"","wpc_theme_onepage_checkout_order_button_text_transform":"uppercase","wpc_theme_onepage_checkout_custom_css":"","wpc_theme_onepage_checkout_content_label_border_type":"content"}',
					),
				)
			),
		);

		$fields['controls']['wpc_onepage_checkout_template_outline_text_heading'] = array(
			'class'           => 'WPC\Control\Heading',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'label'           => 'Outline'
		);
		
		$fields['controls']['wpc_onepage_checkout_template_outline'] = array(
			'class'           => 'WPC\Control\Card_Selector',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'cards'           => array(
				array(
					'screenshot' => plugins_url( 'assets/img/templates/outline-7cc7c5.png', __FILE__ ),
					'action' => array( 
						'id' => 'outline#7cc7c5', 
						'value' => '{"wpc_theme_onepage_checkout_content_label_icon_border_size":"30px","wpc_theme_onepage_checkout_mobile_collapsible":"yes","wpc_theme_onepage_checkout_desktop_collapsible":"yes","wpc_theme_onepage_checkout_content_label_icon_border_style":"round","wpc_theme_onepage_checkout_font_family":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_font_base":"12px","wpc_theme_onepage_checkout_container_max_width":"1200px","wpc_theme_onepage_checkout_container_spacing":"50px","wpc_theme_onepage_checkout_content_primary_text_color":"#333333","wpc_theme_onepage_checkout_content_primary_color":"#7cc7c5","wpc_theme_onepage_checkout_content_decoration_text_color":"#ffffff","wpc_theme_onepage_checkout_form_layout":"inline-form","wpc_theme_onepage_checkout_pro_cart_item_image":"yes","wpc_theme_onepage_checkout_content_label_background_color":"","wpc_theme_onepage_checkout_content_label_typography":"Martel Sans","wpc_theme_onepage_checkout_content_label_typography_weight":"400","wpc_theme_onepage_checkout_content_label_typography_style":"","wpc_theme_onepage_checkout_content_label_typography_size":"15px","wpc_theme_onepage_checkout_content_label_text_color":"#ffffff","wpc_theme_onepage_checkout_content_label_height":"50px","wpc_theme_onepage_checkout_content_label_radius":"3px","wpc_theme_onepage_checkout_content_label_text_transform":"uppercase","wpc_theme_onepage_checkout_content_label_icon_type":"","wpc_theme_onepage_checkout_content_label_icon_typography":"Roboto","wpc_theme_onepage_checkout_content_label_icon_typography_weight":"300","wpc_theme_onepage_checkout_content_label_icon_typography_style":"normal","wpc_theme_onepage_checkout_content_label_icon_typography_size":"1em","wpc_theme_onepage_checkout_content_label_icon_color":"#7cc7c5","wpc_theme_onepage_checkout_content_label_icon_border_color":"#ffffff","wpc_theme_onepage_checkout_content_description_visible":"block","wpc_theme_onepage_checkout_content_description_spacing_top":"20px","wpc_theme_onepage_checkout_content_description_spacing_bottom":"10px","wpc_theme_onepage_checkout_content_description_background_color":"#ffffff","wpc_theme_onepage_checkout_content_description_text_color":"#4a4a4a","wpc_theme_onepage_checkout_content_description_line_bottom_color":"#ffffff","wpc_theme_onepage_checkout_content_description_typography":"Roboto","wpc_theme_onepage_checkout_content_description_typography_weight":"900","wpc_theme_onepage_checkout_content_description_typography_style":false,"wpc_theme_onepage_checkout_content_description_typography_size":"15px","wpc_theme_onepage_checkout_content_box_content_background_color":"#ffffff","wpc_theme_onepage_checkout_content_box_content_border_color":"#7cc7c5","wpc_theme_onepage_checkout_content_box_content_border_width":"3px","wpc_theme_onepage_checkout_content_box_content_spacing":"10px","wpc_theme_onepage_checkout_box_content_order_table_background_color":"#f5f5f5","wpc_theme_onepage_checkout_cupom_button_style":"cupom_button_3d","wpc_theme_onepage_checkout_cupom_button_background_color":"#7cc7c5","wpc_theme_onepage_checkout_order_button_color":"#f5b72e","wpc_theme_onepage_checkout_order_button_spacing":"15px","wpc_theme_onepage_checkout_order_button_radius":"3px","wpc_theme_onepage_checkout_order_button_style":"order_button_3d","wpc_theme_onepage_checkout_order_button_typography":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_order_button_typography_weight":"700","wpc_theme_onepage_checkout_order_button_typography_size":"15px","wpc_theme_onepage_checkout_order_button_text":"","wpc_theme_onepage_checkout_order_button_text_transform":"none","wpc_theme_onepage_checkout_custom_css":"","wpc_theme_onepage_checkout_content_label_border_type":"content"}',
					),
				),
			),
		);

		$fields['controls']['wpc_onepage_checkout_template_flat_text_heading'] = array(
			'class'           => 'WPC\Control\Heading',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'label'           => 'Flat'
		);
		
		$fields['controls']['wpc_onepage_checkout_template_flat'] = array(
			'class'           => 'WPC\Control\Card_Selector',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'cards'           => array(
				array(
					'screenshot' => plugins_url( 'assets/img/templates/flat-4a4a4a.png', __FILE__ ),
					'action' => array( 
					'id' => 'flat#4a4a4a', 
					'value' => '{"wpc_theme_onepage_checkout_mobile_collapsible":"no","wpc_theme_onepage_checkout_desktop_collapsible":"no","wpc_theme_onepage_checkout_font_family":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_font_base":"12px","wpc_theme_onepage_checkout_container_max_width":"1200px","wpc_theme_onepage_checkout_container_spacing":"50px","wpc_theme_onepage_checkout_content_primary_text_color":"#4a4a4a","wpc_theme_onepage_checkout_content_primary_color":"#4a4a4a","wpc_theme_onepage_checkout_content_decoration_text_color":"#ffffff","wpc_theme_onepage_checkout_form_layout":"inline-form","wpc_theme_onepage_checkout_pro_cart_item_image":"yes","wpc_theme_onepage_checkout_content_label_background_color":"#4a4a4a","wpc_theme_onepage_checkout_content_label_typography":"Martel Sans","wpc_theme_onepage_checkout_content_label_typography_weight":"400","wpc_theme_onepage_checkout_content_label_typography_style":"","wpc_theme_onepage_checkout_content_label_typography_size":"1em","wpc_theme_onepage_checkout_content_label_text_color":"#ffffff","wpc_theme_onepage_checkout_content_label_height":"36px","wpc_theme_onepage_checkout_content_label_radius":"0px","wpc_theme_onepage_checkout_content_label_text_transform":"uppercase","wpc_theme_onepage_checkout_content_label_icon_type":"","wpc_theme_onepage_checkout_content_label_icon_typography":"Roboto","wpc_theme_onepage_checkout_content_label_icon_typography_weight":"300","wpc_theme_onepage_checkout_content_label_icon_typography_style":"normal","wpc_theme_onepage_checkout_content_label_icon_typography_size":"1.2em","wpc_theme_onepage_checkout_content_label_icon_color":"#ffffff","wpc_theme_onepage_checkout_content_label_icon_border_style":"","wpc_theme_onepage_checkout_content_label_icon_border_color":"#ffffff","wpc_theme_onepage_checkout_content_description_visible":"block","wpc_theme_onepage_checkout_content_description_spacing_top":"14px","wpc_theme_onepage_checkout_content_description_spacing_bottom":"14px","wpc_theme_onepage_checkout_content_description_background_color":"#ececec","wpc_theme_onepage_checkout_content_description_text_color":"#4a4a4a","wpc_theme_onepage_checkout_content_description_line_bottom_color":"#ffffff","wpc_theme_onepage_checkout_content_description_typography":"Roboto","wpc_theme_onepage_checkout_content_description_typography_weight":"400","wpc_theme_onepage_checkout_content_description_typography_style":false,"wpc_theme_onepage_checkout_content_description_typography_size":"1em","wpc_theme_onepage_checkout_content_box_content_background_color":"#ffffff","wpc_theme_onepage_checkout_content_box_content_border_color":"#dddddd","wpc_theme_onepage_checkout_content_box_content_border_width":"1px","wpc_theme_onepage_checkout_content_box_content_spacing":"8px","wpc_theme_onepage_checkout_box_content_order_table_background_color":"#f5f5f5","wpc_theme_onepage_checkout_cupom_button_style":"","wpc_theme_onepage_checkout_cupom_button_background_color":"","wpc_theme_onepage_checkout_order_button_color":"#fd840e","wpc_theme_onepage_checkout_order_button_spacing":"8px","wpc_theme_onepage_checkout_order_button_radius":"2px","wpc_theme_onepage_checkout_order_button_style":"","wpc_theme_onepage_checkout_order_button_typography":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_order_button_typography_weight":"700","wpc_theme_onepage_checkout_order_button_typography_size":"1.6em","wpc_theme_onepage_checkout_order_button_text":"","wpc_theme_onepage_checkout_order_button_text_transform":"uppercase","wpc_theme_onepage_checkout_custom_css":"","wpc_theme_onepage_checkout_content_label_border_type":""}',
					),
				),
			),
		);

		$fields['controls']['wpc_onepage_checkout_template_solid_text_heading'] = array(
			'class'           => 'WPC\Control\Heading',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'label'           => 'Solid'
		);
		
		$fields['controls']['wpc_onepage_checkout_template_solid'] = array(
			'class'           => 'WPC\Control\Card_Selector',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'cards'           => array(
				array(
					'screenshot' => plugins_url( 'assets/img/templates/solid-ff0000.png', __FILE__ ),
					'action' => array( 
						'id' => 'solid#ff0000', 
						'value' => '{"wpc_theme_onepage_checkout_content_label_icon_border_size":"30px","wpc_theme_onepage_checkout_mobile_collapsible":"yes","wpc_theme_onepage_checkout_desktop_collapsible":"yes","wpc_theme_onepage_checkout_font_family":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_font_base":"12px","wpc_theme_onepage_checkout_container_max_width":"1200px","wpc_theme_onepage_checkout_container_spacing":"50px","wpc_theme_onepage_checkout_content_primary_text_color":"#4a4a4a","wpc_theme_onepage_checkout_content_primary_color":"#f4f4f4","wpc_theme_onepage_checkout_content_decoration_text_color":"#ffffff","wpc_theme_onepage_checkout_form_layout":"inline-form","wpc_theme_onepage_checkout_pro_cart_item_image":"yes","wpc_theme_onepage_checkout_content_label_background_color":"#f4f4f4","wpc_theme_onepage_checkout_content_label_typography":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_content_label_typography_weight":"600","wpc_theme_onepage_checkout_content_label_typography_style":"","wpc_theme_onepage_checkout_content_label_typography_size":"1.15em","wpc_theme_onepage_checkout_content_label_text_color":"#333333","wpc_theme_onepage_checkout_content_label_height":"55px","wpc_theme_onepage_checkout_content_label_radius":"5px","wpc_theme_onepage_checkout_content_label_text_transform":"none","wpc_theme_onepage_checkout_content_label_icon_type":"","wpc_theme_onepage_checkout_content_label_icon_typography":"Roboto","wpc_theme_onepage_checkout_content_label_icon_typography_weight":"400","wpc_theme_onepage_checkout_content_label_icon_typography_style":"normal","wpc_theme_onepage_checkout_content_label_icon_typography_size":"1.2em","wpc_theme_onepage_checkout_content_label_icon_color":"#ffffff","wpc_theme_onepage_checkout_content_label_icon_border_style":"round","wpc_theme_onepage_checkout_content_label_icon_border_color":"#ff0000","wpc_theme_onepage_checkout_content_description_visible":"block","wpc_theme_onepage_checkout_content_description_spacing_top":"4px","wpc_theme_onepage_checkout_content_description_spacing_bottom":"14px","wpc_theme_onepage_checkout_content_description_background_color":"#f4f4f4","wpc_theme_onepage_checkout_content_description_text_color":"#4a4a4a","wpc_theme_onepage_checkout_content_description_line_bottom_color":"#ff0000","wpc_theme_onepage_checkout_content_description_typography":"Roboto","wpc_theme_onepage_checkout_content_description_typography_weight":"400","wpc_theme_onepage_checkout_content_description_typography_style":false,"wpc_theme_onepage_checkout_content_description_typography_size":"1em","wpc_theme_onepage_checkout_content_box_content_background_color":"#f4f4f4","wpc_theme_onepage_checkout_content_box_content_border_color":"#e8e8e8","wpc_theme_onepage_checkout_content_box_content_border_width":"2px","wpc_theme_onepage_checkout_content_box_content_spacing":"8px","wpc_theme_onepage_checkout_box_content_order_table_background_color":"#f4f4f4","wpc_theme_onepage_checkout_cupom_button_style":"","wpc_theme_onepage_checkout_cupom_button_background_color":"#ff0000","wpc_theme_onepage_checkout_order_button_color":"#ff0000","wpc_theme_onepage_checkout_order_button_spacing":"9px","wpc_theme_onepage_checkout_order_button_radius":"0px","wpc_theme_onepage_checkout_order_button_style":"","wpc_theme_onepage_checkout_order_button_typography":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_order_button_typography_weight":"600","wpc_theme_onepage_checkout_order_button_typography_size":"1.4em","wpc_theme_onepage_checkout_order_button_text":"","wpc_theme_onepage_checkout_order_button_text_transform":"uppercase","wpc_theme_onepage_checkout_custom_css":"#wpc-wrapper #wpc-main .form-row .input-text, #wpc-wrapper #wpc-main .form-row select, #wpc-wrapper #wpc-main .form-row .select2-container--default .select2-selection--single { background: white; border-radius: 3px !important; }","wpc_theme_onepage_checkout_content_label_border_type":"content"}',
					),
				),
			),
		);

		$fields['controls']['wpc_onepage_checkout_template_square_text_heading'] = array(
			'class'           => 'WPC\Control\Heading',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'label'           => 'Square'
		);
		
		$fields['controls']['wpc_onepage_checkout_template_square'] = array(
			'class'           => 'WPC\Control\Card_Selector',
			'section'         => 'wpc_template_selector',
			'settings'        => 'wpc_template_selector_active',
			'cards'           => array(
				array(
					'screenshot' => plugins_url( 'assets/img/templates/square-ff4c69.png', __FILE__ ),
					'action' => array( 
						'id' => 'square#ff4c69', 
						'value' => '{"wpc_theme_onepage_checkout_content_label_icon_border_size":"32px","wpc_theme_onepage_checkout_mobile_collapsible":"yes","wpc_theme_onepage_checkout_desktop_collapsible":"yes","wpc_theme_onepage_checkout_font_family":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_font_base":"12px","wpc_theme_onepage_checkout_container_max_width":"1200px","wpc_theme_onepage_checkout_container_spacing":"50px","wpc_theme_onepage_checkout_content_primary_text_color":"#333333","wpc_theme_onepage_checkout_content_primary_color":"#ff4f6c","wpc_theme_onepage_checkout_content_decoration_text_color":"#ffffff","wpc_theme_onepage_checkout_form_layout":"inline-form","wpc_theme_onepage_checkout_pro_cart_item_image":"yes","wpc_theme_onepage_checkout_content_label_background_color":"#ffffff","wpc_theme_onepage_checkout_content_label_typography":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_content_label_typography_weight":"600","wpc_theme_onepage_checkout_content_label_typography_style":"","wpc_theme_onepage_checkout_content_label_typography_size":"16px","wpc_theme_onepage_checkout_content_label_text_color":"#ff4f6c","wpc_theme_onepage_checkout_content_label_height":"55px","wpc_theme_onepage_checkout_content_label_radius":"0px","wpc_theme_onepage_checkout_content_label_border_type":"content","wpc_theme_onepage_checkout_content_label_text_transform":"none","wpc_theme_onepage_checkout_content_label_icon_type":"","wpc_theme_onepage_checkout_content_label_icon_typography":"Roboto","wpc_theme_onepage_checkout_content_label_icon_typography_weight":"500","wpc_theme_onepage_checkout_content_label_icon_typography_style":"normal","wpc_theme_onepage_checkout_content_label_icon_typography_size":"1em","wpc_theme_onepage_checkout_content_label_icon_color":"#ffffff","wpc_theme_onepage_checkout_content_label_icon_border_style":"square","wpc_theme_onepage_checkout_content_label_icon_border_color":"#ff4f6c","wpc_theme_onepage_checkout_content_description_visible":"block","wpc_theme_onepage_checkout_content_description_spacing_top":"12px","wpc_theme_onepage_checkout_content_description_spacing_bottom":"14px","wpc_theme_onepage_checkout_content_description_background_color":"#ffffff","wpc_theme_onepage_checkout_content_description_text_color":"#4a4a4a","wpc_theme_onepage_checkout_content_description_line_bottom_color":"#ff4f6c","wpc_theme_onepage_checkout_content_description_typography":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_content_description_typography_weight":"600","wpc_theme_onepage_checkout_content_description_typography_style":false,"wpc_theme_onepage_checkout_content_description_typography_size":"12px","wpc_theme_onepage_checkout_content_box_content_background_color":"#ffffff","wpc_theme_onepage_checkout_content_box_content_border_color":"#eeeeee","wpc_theme_onepage_checkout_content_box_content_border_width":"2px","wpc_theme_onepage_checkout_content_box_content_spacing":"8px","wpc_theme_onepage_checkout_box_content_order_table_background_color":"#f6f6f6","wpc_theme_onepage_checkout_cupom_button_style":"cupom_button_outline","wpc_theme_onepage_checkout_cupom_button_background_color":"#ff4f6c","wpc_theme_onepage_checkout_order_button_color":"#ff4f6c","wpc_theme_onepage_checkout_order_button_spacing":"15px","wpc_theme_onepage_checkout_order_button_radius":"3px","wpc_theme_onepage_checkout_order_button_style":"order_button_3d","wpc_theme_onepage_checkout_order_button_typography":"Arial, Helvetica, sans-serif","wpc_theme_onepage_checkout_order_button_typography_weight":"700","wpc_theme_onepage_checkout_order_button_typography_size":"15px","wpc_theme_onepage_checkout_order_button_text":"","wpc_theme_onepage_checkout_order_button_text_transform":"none","wpc_theme_onepage_checkout_custom_css":""}',
					),
				),
			),
		);			
		
		return $fields;
		
	}
	
	add_filter( 'wpc_addon_customizer', 'wpc_onepage_checkout_pro_template_customizer', 10, 4 );
	
}

if ( ! function_exists( 'wpc_onepage_checkout_pro_redirect' ) ) {
 
	function wpc_onepage_checkout_pro_redirect() 
	{
		?>
		<script>
			jQuery( document ).ready( function( $ ) {
				/* Open checkout url */
				wp.customize.section( 'wpc_template_selector', function( section ) {
					section.expanded.bind( function( isExpanded ) {
						
						if ( isExpanded ) {
							wp.customize.previewer.previewUrl.set( '<?php echo esc_js( wc_get_page_permalink( 'checkout' ) ); ?>' );
						}
						
					} );
				} );
			} );
		</script>
		<?php
	}
	add_action( 'wpc_customize_inline_scripts', 'wpc_onepage_checkout_pro_redirect' );

}

if ( is_admin() ) {
	// TGM plugin activation
	require_once dirname( __FILE__ ) . '/inc/tgmp/config.php';
}
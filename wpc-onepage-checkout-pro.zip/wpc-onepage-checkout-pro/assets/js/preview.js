;(function( $, api ) {
	
	api( 'wpc_theme_onepage_checkout_font_family', function( value ) {
		value.bind( function( font ) {
			document.documentElement.style.setProperty( '--wpc-base-font-family', font );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_font_base', function( value ) {
		value.bind( function( size ) {
			document.documentElement.style.setProperty( '--wpc-base-font-size', size );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_primary_text_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-primary-text-color', color );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_decoration_text_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-primary-text-decoration-color', color );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_background_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-label-background-color', color );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_typography', function( value ) {
		value.bind( function( font ) {
			document.documentElement.style.setProperty( '--wpc-label-font-family', font );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_typography_weight', function( value ) {
		value.bind( function( weight ) {
			document.documentElement.style.setProperty( '--wpc-label-font-weight', weight );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_typography_size', function( value ) {
		value.bind( function( size ) {
			document.documentElement.style.setProperty( '--wpc-label-font-size', size );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_typography_style', function( value ) {
		value.bind( function( style ) {
			document.documentElement.style.setProperty( '--wpc-label-font-style', style );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_text_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-label-text-color', color );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_height', function( value ) {
		value.bind( function( height ) {
			document.documentElement.style.setProperty( '--wpc-label-height', height );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_label_radius', function( value ) {
		value.bind( function( radius ) {
			document.documentElement.style.setProperty( '--wpc-label-radius', radius );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_label_text_transform', function( value ) {
		value.bind( function( transform ) {
			document.documentElement.style.setProperty( '--wpc-label-text-transform', transform );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_label_border_type', function( value ) {
		value.bind( function( type ) {
			$( document ).find( '#wpc-wrapper' ).removeClass( 'label-content-border' );
			
			if ( 'content' ===  type ) {
				$( document ).find( '#wpc-wrapper' ).addClass( 'label-content-border' );
			}
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_icon_type', function( value ) {
		value.bind( function( type ) {
			if ( 'image' ===  type ) {
				$( document ).find( '#wpc-wrapper' ).addClass( 'content-box-icon' );
			}else {
				$( document ).find( '#wpc-wrapper' ).removeClass( 'content-box-icon' );
			}			
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_icon_border_style', function( value ) {
		value.bind( function( type ) {
			if ( '' ==  type ) {
				$( document ).find( '#wpc-wrapper' ).removeClass( 'icon-style-square' );
				$( document ).find( '#wpc-wrapper' ).removeClass( 'icon-style-round' );
			}
			if ( 'square' ==  type ) {
				$( document ).find( '#wpc-wrapper' ).addClass( 'icon-style-square' );
				$( document ).find( '#wpc-wrapper' ).removeClass( 'icon-style-round' );
			}
			if ( 'round' ==  type ) {
				$( document ).find( '#wpc-wrapper' ).addClass( 'icon-style-square' );
				$( document ).find( '#wpc-wrapper' ).addClass( 'icon-style-round' );
			}			
		});
	});	

	api( 'wpc_theme_onepage_checkout_content_label_icon_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-label-icon-color', color );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_label_icon_border_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-label-icon-border-color', color );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_icon_border_size', function( value ) {
		value.bind( function( size ) {
			document.documentElement.style.setProperty( '--wpc-label-icon-border-size', size );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_label_icon_typography', function( value ) {
		value.bind( function( font ) {
			document.documentElement.style.setProperty( '--wpc-label-icon-font-family', font );
		});
	});	

	api( 'wpc_theme_onepage_checkout_content_label_icon_typography_weight', function( value ) {
		value.bind( function( weight ) {
			document.documentElement.style.setProperty( '--wpc-label-icon-font-weight', weight );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_icon_typography_size', function( value ) {
		value.bind( function( size ) {
			document.documentElement.style.setProperty( '--wpc-label-icon-font-size', size );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_icon_typography_style', function( value ) {
		value.bind( function( style ) {
			document.documentElement.style.setProperty( '--wpc-label-icon-font-style', style );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_billing_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-billing h2.content-box-title span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-billing h2.content-box-title span' ).text( onepagepro.i18n.label_billing );
			}
			
		});
	});

	api( 'wpc_theme_onepage_checkout_content_label_address_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-address h2.content-box-title span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-address h2.content-box-title span' ).text( onepagepro.i18n.label_address );
			}
			
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_label_shipping_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-shipping h2.content-box-title span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-shipping h2.content-box-title span' ).text( onepagepro.i18n.label_shipping );
			}
			
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_label_payment_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-payment h2.content-box-title span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-payment h2.content-box-title span' ).text( onepagepro.i18n.label_payment );
			}
			
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_label_review_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-review h2.content-box-title span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-review h2.content-box-title span' ).text( onepagepro.i18n.label_review );
			}
			
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_description_background_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-description-background-color', color );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_description_text_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-description-text-color', color );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_description_line_bottom_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-description-line-bottom-color', color );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_description_spacing_top', function( value ) {
		value.bind( function( height ) {
			document.documentElement.style.setProperty( '--wpc-description-spacing-top', height );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_description_spacing_bottom', function( value ) {
		value.bind( function( height ) {
			document.documentElement.style.setProperty( '--wpc-description-spacing-bottom', height );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_description_visible', function( value ) {
		value.bind( function( display ) {
			document.documentElement.style.setProperty( '--wpc-description-visible', display );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_description_typography', function( value ) {
		value.bind( function( font ) {
			document.documentElement.style.setProperty( '--wpc-description-font-family', font );
		});
	});	

	api( 'wpc_theme_onepage_checkout_content_description_typography_weight', function( value ) {
		value.bind( function( weight ) {
			document.documentElement.style.setProperty( '--wpc-description-font-weight', weight );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_description_typography_size', function( value ) {
		value.bind( function( size ) {
			document.documentElement.style.setProperty( '--wpc-description-font-size', size );
		});
	});

	api( 'wpc_theme_onepage_checkout_content_description_typography_style', function( value ) {
		value.bind( function( style ) {
			document.documentElement.style.setProperty( '--wpc-description-font-style', style );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_description_billing_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-billing h3.content-box-subtitle span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-billing h3.content-box-subtitle span' ).text( onepagepro.i18n.description_billing );
			}
			
		});
	});

	api( 'wpc_theme_onepage_checkout_content_description_address_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-address h3.content-box-subtitle span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-address h3.content-box-subtitle span' ).text( onepagepro.i18n.description_address );
			}
			
		});
	});

	api( 'wpc_theme_onepage_checkout_content_description_address_billing', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-address .content-box-frame h3.content-box-subtitle.billing-address span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-address .content-box-frame h3.content-box-subtitle.billing-address span' ).text( onepagepro.i18n.description_address_billing );
			}
			
		});
	});

	api( 'wpc_theme_onepage_checkout_content_description_shipping_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-shipping h3.content-box-subtitle span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-shipping h3.content-box-subtitle span' ).text( onepagepro.i18n.description_shipping );
			}
			
		});
	});

	api( 'wpc_theme_onepage_checkout_content_description_payment_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-payment h3.content-box-subtitle span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-payment h3.content-box-subtitle span' ).text( onepagepro.i18n.description_payment );
			}
			
		});
	});

	api( 'wpc_theme_onepage_checkout_content_description_review_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-review h3.content-box-subtitle span' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '.content-box.content-box-review h3.content-box-subtitle span' ).text( onepagepro.i18n.description_review );
			}
			
		});
	});

	api( 'wpc_theme_onepage_checkout_content_box_content_background_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-content-box-background-color', color );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_box_content_border_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-content-box-border-color', color );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_box_content_border_width', function( value ) {
		value.bind( function( width ) {
			document.documentElement.style.setProperty( '--wpc-content-box-border-width', width );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_content_box_content_spacing', function( value ) {
		value.bind( function( spacing ) {
			document.documentElement.style.setProperty( '--wpc-content-box-spacing', spacing );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_order_button_spacing', function( value ) {
		value.bind( function( spacing ) {
			document.documentElement.style.setProperty( '--wpc-content-box-order-button-spacing', spacing );
		});
	});

	api( 'wpc_theme_onepage_checkout_order_button_radius', function( value ) {
		value.bind( function( radius ) {
			document.documentElement.style.setProperty( '--wpc-content-box-order-button-radius', radius );
		});
	});

	api( 'wpc_theme_onepage_checkout_order_button_text_transform', function( value ) {
		value.bind( function( transform ) {
			document.documentElement.style.setProperty( '--wpc-content-box-order-button-text-transform', transform );
		});
	});

	api( 'wpc_theme_onepage_checkout_order_button_style', function( value ) {
		value.bind( function( style ) {
			$( document ).find( '#wpc-wrapper' ).removeClass( 'order_button_shadow' );
			$( document ).find( '#wpc-wrapper' ).removeClass( 'order_button_outline' );
			$( document ).find( '#wpc-wrapper' ).removeClass( 'order_button_3d' );
			
			if ( '' !==  style ) {
				$( document ).find( '#wpc-wrapper' ).addClass( style );
			}
		});
	});

	api( 'wpc_theme_onepage_checkout_cupom_button_style', function( value ) {
		value.bind( function( style ) {
			$( document ).find( '#wpc-wrapper' ).removeClass( 'cupom_button_outline' );
			$( document ).find( '#wpc-wrapper' ).removeClass( 'cupom_button_3d' );
			
			if ( '' !==  style ) {
				$( document ).find( '#wpc-wrapper' ).addClass( style );
			}
		});
	});

	api( 'wpc_theme_onepage_checkout_cupom_button_background_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-content-box-cupom_button-background-color', color );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_order_button_typography', function( value ) {
		value.bind( function( font ) {
			document.documentElement.style.setProperty( '--wpc-content-box-order-button-font-family', font );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_order_button_typography_weight', function( value ) {
		value.bind( function( weight ) {
			document.documentElement.style.setProperty( '--wpc-content-box-order-button-font-weight', weight );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_order_button_typography_size', function( value ) {
		value.bind( function( size ) {
			document.documentElement.style.setProperty( '--wpc-content-box-order-button-font-size', size );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_box_content_order_table_background_color', function( value ) {
		value.bind( function( color ) {
			document.documentElement.style.setProperty( '--wpc-content-box-order-table-background-color', color );
		});
	});
	
	api( 'wpc_theme_onepage_checkout_order_button_text', function( value ) {
		value.bind( function( text ) {
			if( '' !== text ) {
				$( document ).find( '#wpc-wrapper' ).find( '#place_order' ).text( text );
			} else {
				$( document ).find( '#wpc-wrapper' ).find( '#place_order' ).text( onepagepro.i18n.place_order );
			}
			
		});
	});
	
})( jQuery, wp.customize );
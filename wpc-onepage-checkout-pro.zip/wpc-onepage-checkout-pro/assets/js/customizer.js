;(function( $, api ) {
	api.bind('ready', function () {
		
		api.control('wpc_theme_onepage_checkout_content_label_icon_type', function (control) {
			control.setting.bind(function (value) {
				switch (value) {
					case '':
						api.control('wpc_theme_onepage_checkout_content_label_icon_typography').activate();
						api.control('wpc_theme_onepage_checkout_content_label_icon_typography_weight').activate();
						api.control('wpc_theme_onepage_checkout_content_label_icon_typography_style').activate();
						break;
					case 'image':
						api.control('wpc_theme_onepage_checkout_content_label_icon_typography').deactivate();
						api.control('wpc_theme_onepage_checkout_content_label_icon_typography_weight').deactivate();
						api.control('wpc_theme_onepage_checkout_content_label_icon_typography_style').deactivate();
						break;
				}
			});
		});

		api.control('wpc_theme_onepage_checkout_content_label_icon_border_style', function (control) {
			control.setting.bind(function (value) {
				switch (value) {
					case '':
						api.control('wpc_theme_onepage_checkout_content_label_icon_border_color').deactivate();
						api.control('wpc_theme_onepage_checkout_content_label_icon_border_size').deactivate();
						break;
					case 'round':
					case 'square':
						api.control('wpc_theme_onepage_checkout_content_label_icon_border_color').activate();
						api.control('wpc_theme_onepage_checkout_content_label_icon_border_size').activate();
						break;
				}
			});
		});
	});
	
})( jQuery, wp.customize );
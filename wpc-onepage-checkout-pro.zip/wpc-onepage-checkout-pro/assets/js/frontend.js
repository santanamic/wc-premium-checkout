(function( $ ) {
	
	$( document.body ).on( 'click', '.toggle-box-frame .content-box-title', function(e) {
		$( this ).closest( '.toggle-box-frame' ).toggleClass( 'hide-box-frame' );
	} );

	$( document.body ).on( 'click', '.check-collapsible', function(e) {
		if( $( '#next-box-content' ).length >= 1 ) {
			$('html, body').animate({
				scrollTop: $( '#next-box-content' ).closest( '.content-box' ).removeClass( 'hide-box-frame' ).offset().top - 100
			}, 800);
			
			e.preventDefault();
		} else {
			e.returnValue = true;
		}		
	} );
	
	$( document.body ).on( 'click', '.button-of', function(e) {
		var box = $( this ).closest( '.content-box' );

		$( '.content-box' ).delay( 800 ).each( function( i ) {
			if( box[0] == this ) {
				var next_content = $( $( '.content-box' )[i+1] );
				
				$('html, body').animate({
					scrollTop: $( $( '.content-box' )[i+1] ).addClass( 'toggle-box-frame' ).removeClass( 'hide-box-frame' ).offset().top - 100
				}, 800);
				if( $( window ).width() <= 800 ) {
					$( $( '.content-box:not(.content-box-review)' )[i+1] ).find( '.content-box-frame:last-child' ).append( '<div id="next-box-content"><a href="javascript:void(0)" class="button-of">' + onepageprof.collapsible.text + '</a></div>' );
				} else {
					$( $( '.content-box:not(.content-box-review):not(.content-box-payment)' )[i+1] ).find( '.content-box-frame:last-child' ).append( '<div id="next-box-content"><a href="javascript:void(0)" class="button-of">' + onepageprof.collapsible.text + '</a></div>' );
				}
			}
		} );
		$( this ).closest( '#next-box-content' ).remove();
		
		e.preventDefault();
	} );
	
	if( 'yes' === onepageprof.collapsible.desktop || 'yes' === onepageprof.collapsible.mobile ) { 
		if( $( window ).width() <= 800 && 'yes' === onepageprof.collapsible.mobile ) {
			$( '#wpc-wrapper #wpc-main .step-colum .content-box' ).addClass( 'hide-box-frame' );
		} else if( 'yes' === onepageprof.collapsible.desktop ) {
			$( '#wpc-wrapper #wpc-main .step-colum .content-box:not(.content-box-review):not(.content-box-billing)' ).addClass( 'hide-box-frame' );
		}

		$( '#wpc-wrapper #wpc-main .step-colum .content-box.content-box-billing, #wpc-wrapper #wpc-main .step-colum .content-box.content-box-review' ).addClass( 'toggle-box-frame ' );
		$( '#wpc-wrapper #wpc-main .step-colum .toggle-box-frame.content-box:not(.content-box-review) .content-box-frame:last-child' ).append( '<div id="next-box-content"><a href="javascript:void(0)" class="button-of">' + onepageprof.collapsible.text + '</a></div>' );
		$( '#place_order' ).addClass( 'check-collapsible' );
	}
	
})( jQuery );